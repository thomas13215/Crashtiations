# Crashtiations
Development git for Crashtiations | Mr. Duff, Intro to Studio Tech Applications, 2nd Period

Story Slides: https://docs.google.com/presentation/d/1djARTJUl9HK3mrv6QaNrAN2920o_xCQn1Y5nw_LVdqs/edit?usp=sharing

Tutorial One: https://youtu.be/lv8JDpccBqc

# COMMUNICATE TO WHERE WE DONT HAVE 2 PEOPLE WORKING ON THE SAME VERSION! WAIT FOR WHOEVERS WORKING ON A VERSION TO BE FINISHED OR ASK HIM TO PAUSE AND UPLOAD WHAT HE HAS, DOWNLOAD THAT AND WORK BLAH BLAH YEAH

